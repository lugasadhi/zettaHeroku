Use these json as dummy observable via http.

1. corrector-list.json is all cross corrector of all school.
2. school-corrector-list.json is grouping the cross corrector per school, you can use it for the dropdown of cross corrector inside table
3. school-list.json is all school available.
4. school-table-list.json is the data on the table of school
5. students-table-list.json is the data on table of student 